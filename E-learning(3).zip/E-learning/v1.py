import pygame
import random

# 初始化
pygame.init()
SCREEN_WIDTH, SCREEN_HEIGHT = 800, 600
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("拼字遊戲")
FONT = pygame.font.Font(None, 74)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

word_list = ["PYTHON", "GAME", "LEARN", "SPELL", "CODE"]

def get_scrambled_word():
    word = random.choice(word_list)
    scrambled = list(word)
    random.shuffle(scrambled)
    return word, ''.join(scrambled)

def draw_game(scrambled_word, player_input, score):
    screen.fill(WHITE)
    
    # 顯示混亂的字母提示
    text = FONT.render(f"Unscramble: {scrambled_word}", True, BLACK)
    screen.blit(text, (100, 150))
    
    # 顯示輸入框和玩家的輸入
    pygame.draw.rect(screen, BLACK, (100, 250, 600, 80), 4)  # 畫出輸入框
    input_text = FONT.render(f"{player_input}", True, BLACK)
    screen.blit(input_text, (110, 260))  # 顯示玩家輸入的文字在框內

    # 顯示分數
    score_text = FONT.render(f"Score: {score}", True, BLACK)
    screen.blit(score_text, (100, 350))

correct_word, scrambled_word = get_scrambled_word()
player_input = ""
score = 0

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_RETURN:  # 按下Enter鍵檢查答案
                if player_input.upper() == correct_word:
                    score += 1
                    correct_word, scrambled_word = get_scrambled_word()
                    player_input = ""  # 重置玩家輸入
                else:
                    player_input = ""  # 如果錯誤，清空輸入框
            elif event.key == pygame.K_BACKSPACE:  # 按下Backspace刪除字母
                player_input = player_input[:-1]
            else:  # 其他字母輸入
                player_input += event.unicode.upper()

    draw_game(scrambled_word, player_input, score)
    pygame.display.flip()  # 更新畫面

pygame.quit()
