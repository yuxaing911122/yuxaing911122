document.addEventListener('DOMContentLoaded', function () {
    const startButton = document.getElementById("startLearningBtn");
    if (startButton) {
        startButton.addEventListener("click", startLearning);
    }
});

let wordData = []; // 保存單字資料
let currentIndex = 0; // 當前顯示的索引
let language = 'en'; // 目前語言設定，預設為英文

function startLearning() {
    var selectedUnit = document.getElementById("learning-unit").value; // 取得選擇的單元
    var contentDiv = document.getElementById("unit-content");

    switch (selectedUnit) {
        case "Fractions and Decimals":
            loadContent("Fractions and Decimals.txt", contentDiv);
            break;
        case "unit2":
            loadContent("unit2.txt", contentDiv);
            break;
        case "unit3":
            loadContent("unit3.txt", contentDiv);
            break;
        case "unit4":
            loadContent("unit4.txt", contentDiv);
            break;
        default:
            contentDiv.innerHTML = "<p>請選擇一個學習單元。</p>";
            break;
    }
}

function loadContent(fileName, contentDiv) {
    fetch(fileName)
        .then(response => {
            if (!response.ok) {
                throw new Error('檔案未找到');
            }
            return response.text();
        })
        .then(text => {
            const lines = text.split('\n');
            wordData = []; // 重置單字資料
            let currentTerm = "", definition = "", example = "";
            let chineseTerm = "", chineseDefinition = "", chineseExample = ""; // Declare variables
            let imagePath = ""; // Declare variable for image path



            lines.forEach(line => {
                if (line.includes(" - definition:")) {
                    currentTerm = line.split(" - definition:")[0].trim();
                    definition = line.split(" - definition:")[1].trim();
                }

                if (line.includes(" - example:")) {
                    example = line.split(" - example:")[1].trim();
                }

                if (line.includes(" - 定義：")) { // 中文定義
                    chineseTerm = line.split(" - 定義：")[0].trim();
                    chineseDefinition = line.split(" - 定義：")[1].trim();
                }

                if (line.includes(" - 例：")) { // 中文例句
                    chineseExample = line.split(" - 例：")[1].trim();
                }

                if (line.includes("photo\\")) {
                    imagePath = `/photo/${line.split("photo\\")[1].trim().replace('\\', '/')}`;
                }

                if (currentTerm && definition && example && chineseTerm && chineseDefinition && chineseExample && imagePath) {
                    wordData.push({
                        term: currentTerm, 
                        definition: definition, 
                        example: example,
                        chineseTerm: chineseTerm, 
                        chineseDefinition: chineseDefinition, chineseExample: chineseExample,
                        imagePath: imagePath // Add image path to word data
                    });
                    currentTerm = "";
                    definition = "";
                    example = "";
                    chineseTerm = "";
                    chineseDefinition = "";
                    chineseExample = "";
                    imagePath = "";
                }
            });

            if (wordData.length > 0) {
                currentIndex = 0; // 從第一個開始
                displayWord(contentDiv, wordData[currentIndex]);
            } else {
                contentDiv.innerHTML = "<p>沒有找到資料。</p>";
            }
        })
        .catch(error => {
            console.error("錯誤:", error);
            contentDiv.innerHTML = "<p>載入內容失敗，請稍後再試。</p>";
        });
}

function toggleLanguage() {
    language = language === 'en' ? 'zh' : 'en'; // 切換語言
    const contentDiv = document.getElementById("unit-content");
    
    displayWord(contentDiv, wordData[currentIndex]); // 重新顯示單字
    // 更新語言切換按鈕的文字
    const toggleLanguageButton = document.getElementById("toggleLanguageBtn");
    toggleLanguageButton.textContent = language === 'en' ? "Switch to Chinese" : "Switch to English";
    
}

let flipState = true; // 用來追蹤顯示的面是正面還是背面

function displayWord(contentDiv, word) {
    const wordContainer = document.createElement("div");
    wordContainer.className = "term-container flip-in"; // 加入翻頁進入動畫
    
    let termContent = language === 'en' ? word.term : `${word.chineseTerm} (${word.term})`;
    let definitionContent = language === 'en' ? word.definition : word.chineseDefinition;
    let exampleContent = language === 'en' ? word.example : word.chineseExample;
    let imagePath = word.imagePath; // Ensure imagePath is correctly accessed

    // Log imagePath for debugging
    console.log('Image Path:', imagePath);

    wordContainer.innerHTML = `
    <div class="content-wrapper">
        <div class="text-box">
            <h3>
                <span id="term">${termContent}</span>
                <button class="play-button" onclick="speakText('${termContent}', 'term')">pronunciation</button>
            </h3>
            <p>Definition: <br>${definitionContent}</p>
            <p>Example:<br>${exampleContent}</p>
        </div>
        ${imagePath ? `<div class="image-box"><img src="${imagePath}" alt="${termContent}"></div>` : ''}
    </div>
`;


    // 只創建一次 Next 按鈕
    let nextButton = document.getElementById("nextWordBtn");
    if (!nextButton) {
        nextButton = document.createElement("button");
        nextButton.id = "nextWordBtn";
        nextButton.classList.add("fixed-size"); // 添加類名
        nextButton.textContent = "Next";
        nextButton.onclick = showNextWord;
    }

    // 只創建一次 Toggle Language 按鈕
    let toggleLanguageButton = document.getElementById("toggleLanguageBtn");
    if (!toggleLanguageButton) {
        toggleLanguageButton = document.createElement("button");
        toggleLanguageButton.id = "toggleLanguageBtn"; // 設定 id
        toggleLanguageButton.classList.add("fixed-size"); // 添加類名
        toggleLanguageButton.onclick = toggleLanguage;
    }

    // 更新按鈕的文字
    toggleLanguageButton.textContent = language === 'en' ? "Switch to Chinese" : "Switch to English";

    contentDiv.innerHTML = ""; // 清空舊內容
    contentDiv.appendChild(wordContainer);
   
}

function showNextWord() {
    const contentDiv = document.getElementById("unit-content");
    const wordContainer = contentDiv.querySelector(".term-container");

    // 加入翻頁退出動畫
    wordContainer.classList.add("flip-out");

    // 等待動畫結束後顯示下一個單字
    wordContainer.addEventListener("animationend", () => {
        currentIndex = (currentIndex + 1) % wordData.length; // 循環顯示
        displayWord(contentDiv, wordData[currentIndex]);
    }, { once: true });
}

function slideInEffect(element) {
    element.style.transition = "transform 0.5s ease-out, opacity 0.5s ease-out";
    element.style.transform = "translateX(100%)"; // 初始位置
    element.style.opacity = "0";

    setTimeout(() => {
        element.style.transform = "translateX(0)";
        element.style.opacity = "1";
    }, 100);
}

function speakText(text, elementId) {
    var utterance = new SpeechSynthesisUtterance(text);
    var voices = speechSynthesis.getVoices();
    if (voices.length === 0) {
        speechSynthesis.onvoiceschanged = function () {
            voices = speechSynthesis.getVoices();
            setVoice(voices, utterance);
            speechSynthesis.speak(utterance);
        };
    } else {
        setVoice(voices, utterance);
        speechSynthesis.speak(utterance);
    }
    highlightText(elementId);
}

function setVoice(voices, utterance) {
    var selectedVoice = voices.find(voice => voice.lang.startsWith('en'));
    if (language === 'en') {
        // Select an English voice
        selectedVoice = voices.find(voice => voice.lang.startsWith('en'));
    } else if (language === 'zh') {
        // Select a Chinese voice
        selectedVoice = voices.find(voice => voice.lang.startsWith('zh'));
    }

    if (selectedVoice) {
        utterance.voice = selectedVoice;
    } else {
        // Default to the first available voice if specific one is not found
        utterance.voice = voices[0];
    }
    utterance.rate = 1;
    utterance.pitch = 1;
    utterance.volume = 1;
}

function highlightText(elementId) {
    const termElement = document.getElementById(elementId);
    if (termElement) {
        termElement.style.color = "red";
        setTimeout(() => {
            termElement.style.color = "";
        }, 1000);
    }
}

function toggleView() {
    
    const unitSelection = document.querySelector(".unit-selection"); // 單元選擇容器
    const unitContent = document.getElementById("unit-content"); // 單元內容容器
    const buttonContainer = document.querySelector(".button-container"); // 按鈕容器
    const tableView = document.getElementById("table-view"); // 表格模式容器
    const toggleViewButton = document.getElementById("toggleViewBtn");
    //const toggleLanguageBtn = document.getElementById("toggleLanguageBtn");
    //const nextWordBtn = document.getElementById("nextWordBtn");

    if (tableView.classList.contains("hidden")) {
        // 切換到表格模式
        tableView.classList.remove("hidden");
        unitSelection.classList.add("hidden");
        unitContent.classList.add("hidden");
        //buttonContainer.style.display = "none"; // 隐藏按鈕容器

        // 隐藏其他按钮，仅保留切换到表格视图按钮可见
        document.getElementById("nextWordBtn").style.visibility = "hidden";
        document.getElementById("toggleLanguageBtn").style.visibility = "hidden";
        
        toggleViewButton.style.visibility = "visible"; // 保留切换到表格视图按钮可见
        toggleViewButton.textContent = "Switch to Learning View";
        // 设置按钮位置（表格模式下）
        toggleViewButton.style.position = "absolute";
        toggleViewButton.style.visibility = "visible";
        
        // Add Back to Top Button
        const backToTopButton = document.createElement("button");
        backToTopButton.textContent = "Back to Top";
        backToTopButton.style.position = "fixed"; // 固定位置
        backToTopButton.style.right = "10px"; // 距离右侧
        backToTopButton.style.bottom = "10px"; // 距离底部
        backToTopButton.style.zIndex = "1000"; // Ensure it's above other elements
        backToTopButton.style.backgroundColor = "rgba(105, 133, 255, 0.5)"; // Set semi-transparent color
        backToTopButton.onclick = () => window.scrollTo({ top: 0, behavior: "smooth" }); // Scroll to the top smoothly

        document.body.appendChild(backToTopButton); // Append the button to the body, so it remains fixed on scroll
        
        populateTable(); // 填充表格數據
    } else {
        // 切換到學習模式
        tableView.classList.add("hidden");
        unitSelection.classList.remove("hidden");
        unitContent.classList.remove("hidden");
        buttonContainer.style.display = "block"; // 恢复按钮容器的可见性
        // 恢复所有按钮的可见性
        document.getElementById("nextWordBtn").style.visibility = "visible";
        document.getElementById("toggleLanguageBtn").style.visibility = "visible";
        toggleViewButton.textContent = "Switch to Table View";

        // 恢复按钮位置（学习模式下）
    toggleViewButton.style.position = "static"; // 恢复默认布局
    }
}



function populateTable() {
    const tableBody = document.querySelector("#wordTable tbody");
    tableBody.innerHTML = ""; // 清空表格內容

    wordData.forEach(word => {
        const row = document.createElement("tr");

        const termCell = document.createElement("td");
        termCell.textContent = word.term;

        const definitionCell = document.createElement("td");
        definitionCell.textContent = word.definition;

        const exampleCell = document.createElement("td");
        exampleCell.textContent = word.example;

        const imageCell = document.createElement("td");
        if (word.imagePath) {
            const img = document.createElement("img");
            img.src = word.imagePath;
            img.alt = word.term;
            img.style.maxWidth = "100px"; // 調整圖片大小
            imageCell.appendChild(img);
        } else {
            imageCell.textContent = "N/A";
        }

        row.appendChild(termCell);
        row.appendChild(definitionCell);
        row.appendChild(exampleCell);
        row.appendChild(imageCell);
        tableBody.appendChild(row);
    });
}
