document.addEventListener('DOMContentLoaded', function () {
    let currentWord = '';
    let scrambledWord = '';
    let playerInput = '';
    let score = 0;
    let errorCount = 0; // 錯誤計數器
    let challengeStartTime; // 挑戰開始的時間
    let hintsUsed = 0; // 提示次數統計
    let totalErrors = {}; // 存放每個單字的錯誤次數
    let questionCount = 0; // 已回答的題目數
    const maxQuestionsPerLevel = 3; // 每一關的題目數
    let currentLevel = 1; // 當前難度級別

    let difficulty = localStorage.getItem('difficulty') || 'easy'; // 讀取選擇的難度

    // 隱藏 difficulty 元素
    document.getElementById('difficulty').style.display = 'none';
    document.getElementById('difficulty').textContent = difficulty;

    // 從伺服器獲取字庫
    async function fetchWordList() {
        try {
            const response = await fetch('/word-list');
            if (!response.ok) {
                throw new Error('Network response was not ok ' + response.statusText);
            }
            const wordList = await response.json();
            console.log(wordList); // 查看返回的資料
            return wordList;
        } catch (error) {
            console.error('Fetch error: ', error);
            alert('無法獲取字庫資料，請重試！');
        }
    }

     // 點擊按鈕顯示圖片的邏輯
     document.getElementById('show-image-button').addEventListener('click', () => {
        const imageElement = document.getElementById('word-image');
        const buttonText = document.getElementById('show-image-button').textContent;

        if (imageElement.src && imageElement.src !== window.location.href) {
            if (imageElement.style.display === 'block') {
                imageElement.style.display = 'none'; // 隱藏圖片
                document.getElementById('show-image-button').textContent = 'Show image'; // 更改按鈕顯示的字
            } else {
                imageElement.style.display = 'block'; // 顯示圖片
                document.getElementById('show-image-button').textContent = 'Hide image'; // 更改按鈕顯示的字
                hintsUsed++; // 增加提示次數
            }
        } else {
            alert('目前沒有圖片可顯示！');
        }
    });

    let gameCompleted = false; // 添加遊戲狀態標誌

    // 根據難度選擇字
    async function getScrambledWord() {

        if (gameCompleted) return; // 防止已過關的情況下重複調用

        if (!challengeStartTime) {
            challengeStartTime = Date.now(); // 開始計時
        }

        if (score >= 3) {  // *** 新增：檢查是否達到過關分數 ***
            gameCompleted = true; // 更新遊戲狀態
            showCompletionModal(); // 顯示過關彈窗
            return;
        }

        const wordList = await fetchWordList(); // 獲取字庫
        if (!wordList || !wordList[difficulty]) {
            alert('難度字庫不存在！');
            return;
        }
        // 過濾只包含英文的單字
        const words = Object.keys(wordList[difficulty]).filter(word => /^[A-Za-z\s]+$/.test(word)); // 檢查單字是否全為英文字母或空格

        if (words.length === 0) {
        console.error("無可用的英文單字！");
        return; // 確保若無單字時程序終止
        }
        const word = words[Math.floor(Math.random() * words.length)]; // 隨機選擇單字
        
        let scrambled;
        // 檢查單字中是否包含空格
        if (word.includes(' ')) {
            // 將單字分割成多個部分（空格分割）
            const parts = word.split(' ');
            // 分別打亂每個部分
            const scrambledParts = parts.map(part => part.split('').sort(() => Math.random() - 0.5).join(''));
            // 重新合併已打亂的部分
            scrambled = scrambledParts.join(' '); 
        } else {
            // 如果沒有空格，直接打亂整個單字
            scrambled = word.split('').sort(() => Math.random() - 0.5).join('');
        }
        
        currentWord = word;
        scrambledWord = scrambled;
        errorCount = 0; // 重設錯誤計數
        
        const wordData = wordList[difficulty][currentWord]; // 獲取該單字的資料
        
        document.getElementById('scrambled-word').textContent = `Unscramble: ${scrambledWord}`;
        document.getElementById('hint').textContent = `Hint: ${wordData.definition}`;

        document.getElementById('example-sentence').textContent = ''; // 清除例句
        document.getElementById('skip-button').style.display = 'none'; // 確保按鈕隱藏

        document.getElementById('show-image-button').style.display = 'block';


        hideExampleSentence(); // 換題時隱藏例句框

        // 更新圖片
        const imageElement = document.getElementById('word-image');
        if (wordData.image_path) {
            imageElement.src = wordData.image_path;
            imageElement.style.display = 'block';
            imageElement.style.display = 'none'; // 確保圖片初始隱藏
        } else {
            imageElement.src = ''; // 清空圖片路徑
        imageElement.style.display = 'none';
        }

        // 啟用輸入框並清空內容
        document.getElementById('player-input').disabled = false;
        document.getElementById('player-input').value = '';

        
    }

    // 顯示例句
    async function showExampleSentence() {
        const wordList = await fetchWordList(); // 獲取字庫
        if (!wordList || !wordList[difficulty]) {
            console.error('難度字庫不存在！');
            return;
        }
        const wordData = wordList[difficulty][currentWord]; // 獲取該單字的資料
        const exampleSentence = wordData.example; // 獲取例句
        const exampleElement = document.getElementById('example-sentence');

        if (exampleSentence) {
            exampleElement.textContent = `Example: ${exampleSentence}`;
            exampleElement.style.display = 'block'; // 顯示例句框
            document.getElementById('skip-button').style.display = 'block'; // 顯示「叉叉」按鈕
            // 禁用輸入框直到點擊skip按鈕
            document.getElementById('player-input').disabled = true;
        } else {
            console.error('未找到該單字的例句');
            exampleElement.style.display = 'none'; // 如果沒有例句則隱藏
        }
    }

    // 隱藏例句框
    function hideExampleSentence() {
        const exampleElement = document.getElementById('example-sentence');
        exampleElement.style.display = 'none'; // 隱藏例句框
    }

    // 顯示動態提示
    function showDynamicHint() {
        // 確保 wordData 已經正確初始化
        const wordList = fetchWordList(); // 獲取字庫
        wordList.then(wordList => {
            const wordData = wordList[difficulty][currentWord];
            if (!wordData) {
                console.error('單字資料不存在');
                return;
            }

            // 計算應顯示的字母數量：從錯 3 次開始，顯示字母數等於錯誤次數減 2
            const hintLength = Math.min(errorCount - 2, currentWord.length); 

            if (errorCount >= 3) {
                // 如果錯誤次數大於等於3，顯示解釋提示和部分字母
                document.getElementById('hint').innerHTML = `Hint: "${wordData.definition}"<br>(${currentWord.slice(0, hintLength)})`;

                
            } else {
                // 否則僅顯示部分字母
                if (hintLength > 0) { // 確保提示長度大於 0
                    const hint = currentWord.slice(0, hintLength); // 提示前 hintLength 個字母
                    document.getElementById('hint').textContent = `Hint: "${hint}"`;
                } else {
                    document.getElementById('hint').textContent = ''; // 錯誤未達 3 次時不顯示提示
                }
            }
        });
    }

    function showCompletionModal() {
        if (gameCompleted) return; // 避免重複觸發
        gameCompleted = true; // 更新狀態
    
        document.getElementById('player-input').disabled = true; // 禁用輸入框
        const totalTime = ((Date.now() - challengeStartTime) / 1000).toFixed(2); // 計算時間

        
    
        Swal.fire({
            title: '挑戰完成！',
            html: `
                <p>總時間：${totalTime} 秒</p>
                <p>提示次數：${hintsUsed}</p>
                <p>錯誤次數：${totalErrors[currentWord]}</p>
                
                <p>是否要再挑戰一次或更改難度？</p>
                
            `,
            icon: 'success',
            showCancelButton: true,
            confirmButtonText: '再次挑戰',
            cancelButtonText: '更改難度',
            allowOutsideClick: false, // 禁止点击其他区域关闭视窗
        }).then((result) => {
            if (result.isConfirmed) {
                resetGame(); // 如果用户选择了「再次挑战」，则重置游戏
            } else {
                changeDifficulty(); // 如果用户选择了「更改难度」，则进行难度更改
            }
            document.getElementById('player-input').disabled = false; // 启用输入框
        });
    }
    
    
    
    function resetGame() {
        console.log('Game is resetting...'); // 調試訊息
        score = 0;
        questionCount = 0;
        hintsUsed = 0;
        totalErrors = 0;
        challengeStartTime = null;
        currentLevel = 1;
        gameCompleted = false; // 重置遊戲狀態
        getScrambledWord(); // 立即呼叫新題目
    }
    
    function changeDifficulty() {
        Swal.fire({
            title: '選擇難度',
            input: 'select',
            inputOptions: {
                easy: '簡單',
                medium: '中等',
                hard: '困難',
            },
            inputPlaceholder: '選擇一個難度',
            showCancelButton: true,
            confirmButtonText: '確定',
            cancelButtonText: '取消',
        }).then((result) => {
            if (result.isConfirmed && result.value) {
                difficulty = result.value;
                localStorage.setItem('difficulty', difficulty); // 保存難度
                resetGame(); // 重置遊戲
            }
        });
    }
    
    
    

    // 玩家輸入
    document.getElementById('player-input').addEventListener('input', (event) => {
        playerInput = event.target.value.toUpperCase();
    });

    document.getElementById('skip-button').addEventListener('click', () => {
        document.getElementById('skip-button').style.display = 'none'; // 隱藏按鈕
        getScrambledWord(); // 換新題目
    });

    // 按下 Enter 時檢查答案
    document.getElementById('player-input').addEventListener('keydown', (event) => {
        if (event.key === 'Enter') {

            event.preventDefault(); // 防止預設行為，如表單提交


            if (playerInput.toUpperCase() === currentWord.toUpperCase()) {
                score++;
                questionCount++;
                document.getElementById('score').textContent = `分數: ${score}`;
                
                if (score >= 3) {
                    showCompletionModal(); // 顯示結果窗格
                } else {
                    showExampleSentence();
                }
                
            } else {

                // 若錯誤次數超過3次，顯示動態提示
                if (!totalErrors[currentWord]) {
                    totalErrors[currentWord] = 1;
                } else {
                    totalErrors[currentWord]++;
                }

                errorCount++; // 增加錯誤計數
                if (errorCount >= 3) {
                    showDynamicHint(); // 動態提示多顯示字母
                }

               }
            document.getElementById('player-input').value = ''; // 清空輸入框
        }
    });

    
    
    

    // 初始化遊戲
    getScrambledWord();
});
