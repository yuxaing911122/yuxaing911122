// 隨機顏色生成函數
function getRandomColor() {
    const letters = '0123456789ABCDEF';
    let color = '#';
    for (let i = 0; i < 6; i++) {
        color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
}

// 設定隨機顏色
function changeTextColor() {
    document.body.style.color = getRandomColor();  // 設定 body 文字顏色
}

// 每隔一段時間更換文字顏色
setInterval(changeTextColor, 1000);  // 每 1 秒改變一次顏色

document.querySelector('.user-profile-container').addEventListener('click', function(event) {
    event.stopPropagation(); // 阻止事件冒泡
    this.classList.toggle('active'); // 顯示或隱藏選單
});

// 點擊其他地方時隱藏選單
document.addEventListener('click', function(event) {
    const userMenu = document.querySelector('.user-menu');
    if (userMenu && userMenu.classList.contains('active')) {
        userMenu.style.display = 'none';
        document.querySelector('.user-profile-container').classList.remove('active');
    }
});
