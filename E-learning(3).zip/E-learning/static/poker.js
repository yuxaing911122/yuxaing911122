document.addEventListener("DOMContentLoaded", async () => {
    const englishListContainer = document.querySelector("#english-list");
    const chineseListContainer = document.querySelector("#chinese-list");
    const errorCounter = document.querySelector("#error-counter");

    const difficulty = localStorage.getItem('difficulty') || 'easy'; // 預設難度
    const startTime = Date.now(); // 記錄遊戲開始時間
    let language = localStorage.getItem('language') || 'en'; // 儲存語言選擇，預設為英文

    let errorCount = 0; // 初始化錯誤次數
    const maxErrors = 5; // 最大錯誤次數

    let matchedWords = []; // 儲存已匹配的單字對

    changeLanguage(language); // 在網頁加載時根據語言自動切換

    let wordList = null; // 將 wordList 宣告為全局變數

    async function fetchPokerWordList() {
        try {
            const response = await fetch("/word-list-poker");
            if (!response.ok) throw new Error("Failed to fetch word list");
            wordList = await response.json();
            initializeGame(wordList); // 初始化遊戲
        } catch (error) {
            console.error("Error fetching word list:", error);
            alert("無法獲取題庫，請稍後再試！");
        }
    }

    function getRandomPairs(wordList, difficulty, count = 5) {
        if (!wordList[difficulty]) {
            alert("所選難度不存在！");
            return [];
        }

        const allWords = Object.entries(wordList[difficulty]);
        const remainingWords = allWords.filter(([word, translation]) =>
            !matchedWords.some(([mWord, mTranslation]) => mWord === word && mTranslation === translation)
        );

        const shuffled = remainingWords.sort(() => Math.random() - 0.5);
        return shuffled.slice(0, count);
    }

    function generateWordPairHTML(pairs) {
        console.log("生成的配對:", pairs);
        englishListContainer.innerHTML = "";
        chineseListContainer.innerHTML = "";

        const shuffledEnglish = shuffle(pairs.map(pair => pair[0]));
        const shuffledChinese = shuffle(pairs.map(pair => pair[1]));

        shuffledEnglish.forEach(word => {
            const englishCard = document.createElement("div");
            englishCard.classList.add("card", "draggable");
            englishCard.setAttribute("data-word", word);
            englishCard.textContent = word;
            englishListContainer.appendChild(englishCard);
        });

        shuffledChinese.forEach(translation => {
            const chineseCard = document.createElement("div");
            chineseCard.classList.add("card", "droppable");
            chineseCard.setAttribute("data-translation", translation);
            chineseCard.textContent = translation;
            chineseCard.style.whiteSpace = "normal";
            chineseListContainer.appendChild(chineseCard);
        });

        bindClickEvents(pairs);
    }

    function shuffle(array) {
        return array.sort(() => Math.random() - 0.5);
    }

    // 更新錯誤計數器
    function updateErrorCounter() {
        errorCounter.textContent = errorCount;
        if (errorCount >= maxErrors) {
            Swal.fire({
                title: '錯誤次數過多！',
                text: '建議再次學習後再來測試！',
                icon: 'warning',
                confirmButtonText: '了解'
            }).then((result) => {
                if (result.isConfirmed) {
                    history.back(); // 返回上一頁
                }
            });
        }
    }

    function bindClickEvents(pairs) {
        let selectedEnglish = null;
        let selectedChinese = null;
        let matchedPairs = 0;
        const totalPairs = pairs.length;

        const allCards = document.querySelectorAll(".card");
        allCards.forEach(card => {
            card.addEventListener("click", () => {
                if (card.style.opacity === "0.5") return; // Skip if card is already matched

                const isEnglishCard = card.classList.contains("draggable");
                const isChineseCard = card.classList.contains("droppable");

                // Deselect if the same card is clicked again
                if ((isEnglishCard && selectedEnglish === card) || (isChineseCard && selectedChinese === card)) {
                    card.classList.remove("selected");
                    if (isEnglishCard) selectedEnglish = null;
                    if (isChineseCard) selectedChinese = null;
                    return;
                }

                // Handle selection logic
                if (isEnglishCard) {
                    if (selectedEnglish) selectedEnglish.classList.remove("selected");
                    selectedEnglish = card;
                } else if (isChineseCard) {
                    if (selectedChinese) selectedChinese.classList.remove("selected");
                    selectedChinese = card;
                }

                card.classList.add("selected");

                // When both an English and Chinese card are selected, check if they match
                if (selectedEnglish && selectedChinese) {
                    const selectedWord = selectedEnglish.getAttribute("data-word");
                    const selectedTranslation = selectedChinese.getAttribute("data-translation");

                    // Check if they match
                    const isMatch = pairs.some(([word, translation]) => word === selectedWord && translation === selectedTranslation);

                    if (isMatch) {
                        // Mark matched cards as "correct"
                        [selectedEnglish, selectedChinese].forEach(c => {
                            c.style.opacity = "0.5";
                            c.style.pointerEvents = "none";
                        });
                        matchedPairs++;
                        matchedWords.push([selectedWord, selectedTranslation]); // Add to matched list

                        if (matchedPairs === totalPairs) {
                            const remainingPairs = getRandomPairs(wordList, difficulty); // 獲取剩餘單字
                        
                            if (remainingPairs.length > 0) {
                                clearPreviousRound(); // 清空上一輪的內容
                                generateWordPairHTML(remainingPairs); // 開始下一輪
                            } else {
                                // 隱藏所有列表，顯示遊戲成功
                                toggleVisibility(englishListContainer, false);
                                toggleVisibility(chineseListContainer, false);
                        
                                const endTime = Date.now();
                                const timeSpent = ((endTime - startTime) / 1000).toFixed(2);
                                Swal.fire({
                                    title: '遊戲成功！',
                                    html: `
                                    <p>恭喜你完成此單元所有單字</p>
                                    <p>花費時間：${timeSpent} 秒</p>
                                    `,

                                    icon: 'success',
                                    confirmButtonText: '確定'
                                }).then((result) => {
                                    if (result.isConfirmed) {
                                        history.back(); // 返回上一頁
                                    }
                                });
                            }
                        }
                    } else {
                        // Apply incorrect style and set animation
                        [selectedEnglish, selectedChinese].forEach(c => {
                            c.classList.add("incorrect");
                        });

                        // Reset the incorrect styles after animation
                        [selectedEnglish, selectedChinese].forEach(c => {
                            c.addEventListener("animationend", () => {
                                c.classList.remove("incorrect"); // Remove incorrect class after animation
                                c.classList.remove("selected"); // Reset the selected class
                                selectedEnglish = null;
                                selectedChinese = null;
                            });
                        });
                        errorCount++; // 增加錯誤次數
                        updateErrorCounter(); // 更新錯誤計數器
                    }

                    selectedEnglish = null;
                    selectedChinese = null;
                }
            });
        });
    }

    async function initializeGame(wordList) {
        if (!wordList) return;

        const wordPairs = getRandomPairs(wordList, difficulty, 5);
        generateWordPairHTML(wordPairs);
    }

    function changeLanguage(lang) {
        language = lang;
        localStorage.setItem('language', language);
        const wordList = JSON.parse(localStorage.getItem('wordList'));
        if (wordList) {
            generateWordPairHTML(getRandomPairs(wordList, difficulty));
        }
    }

    function clearPreviousRound() {
        englishListContainer.innerHTML = ""; // 清空英文列表
        chineseListContainer.innerHTML = ""; // 清空中文列表
    }
    function toggleVisibility(element, show) {
        if (show) {
            element.classList.add("visible");
            element.classList.remove("hidden");
        } else {
            element.classList.add("hidden");
            element.classList.remove("visible");
        }
    }
    

    fetchPokerWordList();
});
