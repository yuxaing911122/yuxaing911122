from flask import Flask, render_template, jsonify, send_from_directory, request, redirect, url_for, session, flash
import os
import sqlite3

app = Flask(__name__)
app.secret_key = 'muybweb54'  # 為 Flask session 設定一個密鑰

# 提供 photo 資料夾的圖片
@app.route('/photo/<path:filename>')
def serve_photos(filename):
    return send_from_directory('photo', filename)

# 定義讀取檔案的函數
# 讀取字庫的函數
def read_words_from_file(file_path):
    word_dict = {}
    with open(file_path, 'r', encoding='utf-8') as file:
        for line in file:
            if not line.strip():
                continue  # 跳過空行
            parts = line.strip().split(' - ')
            if len(parts) < 2:
                continue  # 確保行內至少有單字和對應內容

            word = parts[0].strip()
            if word not in word_dict:
                word_dict[word] = {'definition': '', 'example': '', 'image_path': ''}  # 初始化單字的解釋和例句

            if parts[1].startswith('definition:'):
                word_dict[word]['definition'] = parts[1].replace('definition:', '').strip()
            elif parts[1].startswith('example:'):
                word_dict[word]['example'] = parts[1].replace('example:', '').strip()
            
            # Assuming images are stored in a folder named 'photo' relative to this script
            image_filename = f"{word}.png"  # Example: 'Denominator.png'
            image_path = f"photo/{image_filename}"  # Ensure it's relative to the 'static' folder
            word_dict[word]['image_path'] = image_path  # Store relative path
    
    return word_dict

def read_poker_words_from_file(file_path):
    """
    專為撲克牌題庫設計，讀取單字與解釋，解析為字典格式。
    格式範例： "Denominator - 分母"
    """
    poker_words = {}
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            for line in file:
                if '-' in line:  # 確保行內有 key-value 的分隔符號
                    key, value = line.strip().split(' - ', 1)
                    poker_words[key.strip()] = value.strip()
        return poker_words
    except Exception as e:
        print(f"Error reading poker words from {file_path}: {e}")
        return {}

# 資料庫初始化
def init_db():
    with sqlite3.connect('users.db') as conn:
        c = conn.cursor()
        c.execute('''CREATE TABLE IF NOT EXISTS users
                     (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE, password TEXT)''')
        conn.commit()

# 管理員查看所有用戶資料頁面
@app.route('/admin')
def admin_users():
    #print("Session data:", session)  # Debug: Print session data
    if 'admin' in session:
        users = get_all_users()  # Fetch user data from your database or data source
        if users:
            print("Fetched users data:", users)  # Debug: Print fetched users data
            return render_template('admin_users.html', users=users)
        else:
            flash('目前沒有用戶。')  # No users found
            return render_template('admin_users.html', users=[])  # Pass an empty list to the template
    else:
        flash('您需要管理員權限才能訪問此頁面！')
        return redirect(url_for('login'))



# 從資料庫中獲取所有用戶資料
def get_all_users():
    with sqlite3.connect('users.db') as conn:
        c = conn.cursor()
        c.execute('SELECT * FROM users')
        users = c.fetchall()
        #print("Fetched users data:", users)  # Debug: Print fetched users data
        for user in users:
            #print(f"User ID: {user[0]}, Username: {user[1]}")  # Debug: Print each user's ID and username
            return users



# 從資料庫中獲取單個用戶的數據
def get_user_data_by_id(user_id):
    with sqlite3.connect('users.db') as conn:
        c = conn.cursor()
        c.execute('SELECT * FROM users WHERE id=?', (user_id,))
        user = c.fetchone()
        if user:
            return {
                'id': user[0],         # 使用者ID
                'username': user[1]    # 使用者名
            }
        else:
            return None

# 登入頁面
@app.route('/')
def home():
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login_user():
    username = request.form['username']
    password = request.form['password']
    
    with sqlite3.connect('users.db') as conn:
        c = conn.cursor()
        c.execute('SELECT * FROM users WHERE username=? AND password=?', (username, password))
        user = c.fetchone()
        
        if user:
            session['username'] = username
            session['user_id'] = user[0]  # Assuming user ID is at index 0 in the tuple
            if username == 'admin':
                session['admin'] = True  # Set admin session key
            else:
                session['admin'] = False  # Ensure non-admins do not have admin access
            flash(' ')
            return redirect(url_for('index' if not session.get('admin') else 'admin_panel'))
        else:
            flash('Username or Password is wrong. Please try again')
            return redirect(url_for('home'))

# 註冊頁面
@app.route('/register')
def register():
    return render_template('register.html')

@app.route('/register', methods=['POST'])
def register_user():
    username = request.form['username']
    password = request.form['password']
    
    with sqlite3.connect('users.db') as conn:
        c = conn.cursor()
        try:
            c.execute('INSERT INTO users (username, password) VALUES (?, ?)', (username, password))
            conn.commit()
            flash('Registration successful!')
            return redirect(url_for('home'))
        except sqlite3.IntegrityError:
            flash('Username already exists!')
            return redirect(url_for('register'))


@app.route('/index')
def index():
    if 'username' in session:
        return render_template('index.html', username=session['username'])
    else:
        flash('請先登入！')
        return redirect(url_for('home'))


# 遊戲頁面
@app.route('/game')
def game():
    if 'username' in session:
        return render_template('game.html')
    else:
        flash('You need to login first!')
        return redirect(url_for('login'))

# 學習頁面
@app.route('/study')
def study():
    if 'username' in session:
        return render_template('study.html')
    else:
        flash('You need to login first!')
        return redirect(url_for('login'))
    
# 管理頁面
@app.route('/admin')
def admin_panel():
    if 'admin' in session:
        return render_template('admin_users.html')
    else:
        flash('You need admin privileges to access this page!')
        return redirect(url_for('login'))
    
# 使用者
@app.route('/user')
def user():
    if 'username' in session:
        return render_template('user.html')
    else:
        flash('You need to login first!')
        return redirect(url_for('login'))
    
@app.route('/logout')
def logout():
    session.clear()  # 清空所有 session 資料
    flash('已成功登出，請重新登入。')  # 添加提示
    response = redirect(url_for('home'))  # 返回登入頁
    response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
    response.headers['Pragma'] = 'no-cache'
    response.headers['Expires'] = '0'
    return response

# Poker 頁面
@app.route('/poker')
def poker():
    if 'username' in session:
        return render_template('poker.html')
    else:
        flash('You need to login first!')
        return redirect(url_for('login'))



# API 端點，提供字庫
@app.route('/word-list', methods=['GET'])
def get_word_list():
    word_list = {
        "unit of measurement": read_words_from_file('unit of measurement.txt'),
        "medium": read_words_from_file('medium.txt'),
        "hard": read_words_from_file('hard.txt'),
        "Fractions and Decimals": read_words_from_file('Fractions and Decimals.txt'),
    }
    return jsonify(word_list)

@app.route('/word-list-poker', methods=['GET'])
def get_word_list_poker():
    try:
        # 使用專用函數讀取題庫
        word_list_poker = {
            "Level1": read_poker_words_from_file('Level1.txt'),
            "Level2": read_poker_words_from_file('Level2.txt'),
            "Level3": read_poker_words_from_file('Level3.txt'),
        }
        return jsonify(word_list_poker)
    except Exception as e:
        print("Error in /word-list-poker:", e)
        return jsonify({"error": "Failed to fetch word list"}), 500


# 設置靜態目錄為當前目錄
@app.route('/<filename>')
def serve_file(filename):
    # 設定文件目錄為當前工作目錄
    return send_from_directory(os.getcwd(), filename)

@app.after_request
def add_header(response):
    response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
    response.headers['Pragma'] = 'no-cache'
    response.headers['Expires'] = '0'
    return response






if __name__ == '__main__':
    init_db()  # 保證資料庫初始化
    app.run(debug=True)