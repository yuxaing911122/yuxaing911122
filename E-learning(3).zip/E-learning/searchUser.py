import sqlite3

def view_all_users():
    try:
        # Connect to the SQLite database
        with sqlite3.connect('users.db') as conn:
            c = conn.cursor()
            # Query to select all users
            c.execute('SELECT * FROM users')
            # Fetch all rows
            users = c.fetchall()
            
            # Print the users
            for user in users:
                print(f"ID: {user[0]}, Username: {user[1]}, password:{user[2]}")
    
    except sqlite3.Error as e:
        print(f"An error occurred: {e}")
    finally:
        # Ensure the connection is always closed
        conn.close()

# Call the function to view all users
view_all_users()
